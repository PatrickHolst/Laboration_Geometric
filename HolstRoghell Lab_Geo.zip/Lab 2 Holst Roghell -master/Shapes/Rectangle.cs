﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Rectangle : Shape2D
    {
        private Vector3 center;
        private Vector2 size;
        public float width;

        public Rectangle(Vector2 center, Vector2 size)
        {
            this.center = new Vector3(center, 0);
            this.size = size;
        }

        public Rectangle(Vector2 center, float width)
        {
            this.center = new Vector3(center, 0);
            this.width = width;
        }

        public override Vector3 Center
        {
            get { return center; }
        }

        public override float Circumference
        {
            get { return size.X * 2 + size.Y * 2; }
        }

        public override float Area
        {
            get { return size.X * size.Y; }
        }

        public bool IsSquare => size.X == size.Y;

        public override string ToString()
        {
            if (IsSquare)
            {
                return $"Square @({Center.X:0.0}, {Center.Y:0.0}): w = {width:0.0}, h = {width:0.0}";
            }
            return $"Rectangle @({Center.X:0.0}, {Center.Y:0.0}): w = {size.X:0.0}, h = {size.Y:0.0}";
        }

    }
}
