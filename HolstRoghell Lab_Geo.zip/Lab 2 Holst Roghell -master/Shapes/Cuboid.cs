﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Cuboid : Shape3D
    {
        public Vector3 Size { get; }
        public override Vector3 Center { get; }
        public override float Volume { get; }

        public override float Area { get; }

        public Cuboid(Vector3 center, Vector3 size)
        {
            Center = center;
            Size = size;
            Area = (2 * Size.Z * Size.X) + (2 * Size.Z * Size.Y) + (2 * Size.X * Size.Y);
            Volume = Size.X * Size.Y * Size.Z;
        }

        public Cuboid(Vector3 center, float width) : this(center, new Vector3(width, width, width))
        {
           
        }

        public bool IsCube
        {
            get
            {
                return (Size.X == Size.Y && Size.X == Size.Z && Size.Y == Size.Z);
            }
        } 

        public override string ToString()
        {
            if (IsCube)
            {
                return $"Cube @({Center.X:0.0}, {Center.Y:0.0}, {Center.Z:0.0}); w = {Size.X:0.0}, h = {Size.Y:0.0}, 1 = {Size.Z:0.0})";
            }
            else
            {
                return $"Cuboid @({Center.X:0.0}, {Center.Y:0.0}, {Center.Z:0.0}): w = {Size.X:0.0}, h = {Size.Y:0.0}, 1 = {Size.Z:0.0})";
            }
        }
    }
}
