﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Circle : Shape2D
    {
        public override Vector3 Center { get; }
        public override float Circumference {get;}
        public override float Area { get; }

        private Vector2 Position;
        private float Radius;
        public Circle(Vector2 position, float radius)
        {
            Position = position;
            Radius = radius;
            Area = (float)Math.PI * radius * radius;
            Circumference = (radius + radius) * MathF.PI;
        }
        public override string ToString()
        {
            return $"Circle @({Position.X:0.0}, {Position.Y:0.0}): r = {Radius:0.0}";
        }
    }
}
