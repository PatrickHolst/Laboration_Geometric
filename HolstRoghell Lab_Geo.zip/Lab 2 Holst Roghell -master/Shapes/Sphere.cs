﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Sphere : Shape3D
    {
        public override float Volume { get; }

        public override Vector3 Center { get; }

        public override float Area { get; }

        public float Radius { get; }

        public Sphere(Vector3 center, float radius)
        {
            Radius = radius;
            Center = center;
            Area = (float)((float)4 * Math.PI * radius * radius);
            Volume = (float)((float)1.3333333 * Math.PI * radius * radius * radius);
        }


        public override string ToString()
        {
            return $"Sphere @({Center.X:0.0}, {Center.Y:0.0}, {Center.Z:0.0}): r = {Radius:0.0}";
        }
    }
}
