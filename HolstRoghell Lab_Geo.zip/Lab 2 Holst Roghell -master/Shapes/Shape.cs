﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public abstract class Shape
    {
        private static Random rnd = new Random();
        public abstract Vector3 Center { get; }
        public abstract float Area { get; }

        public static Shape GenerateShape() => GenerateShape(new Vector3((float)rnd.NextDouble() * 10,
                                                                         (float)rnd.NextDouble() * 10,
                                                                         (float)rnd.NextDouble() * 10));

        public static Shape GenerateShape(Vector3 position)
        {
            int i = rnd.Next(7);
            float scalefactor = 5;
            return i switch
            {
                0 => new Circle(new Vector2(position.X, position.Y), (float)rnd.NextDouble() * scalefactor),
                1 => new Rectangle(new Vector2(position.X, position.Y), new Vector2((float)rnd.NextDouble() * scalefactor, (float)rnd.NextDouble() * scalefactor)),
                2 => new Rectangle(new Vector2(position.X, position.Y), (float)rnd.NextDouble() * scalefactor),
                3 => GenerateTriangle(new Vector2(position.X, position.Y)),
                4 => new Sphere(position, (float)rnd.NextDouble() * scalefactor),
                5 => new Cuboid(position, Vector3.One * (float)rnd.NextDouble() * scalefactor),
                6 => new Cuboid(position, new Vector3((float)rnd.NextDouble() * scalefactor, (float)rnd.NextDouble() * scalefactor, (float)rnd.NextDouble() * scalefactor)),
                _ => null
            };
        }

        private static Triangle GenerateTriangle(Vector2 position)
        {
            var rand = new Random();

            var sumEdge = position * 3f;

            var edgeOne = new Vector2(x: rand.Next(0, 100), y: rand.Next(0, 100));
            var edgeTwo = new Vector2(x: rand.Next(0, 100), y: rand.Next(0, 100));

            while (edgeOne == edgeTwo)
                edgeTwo = new Vector2(x: rand.Next(0, 100), y: rand.Next(0, 100));

            Vector2 edgeThree = (sumEdge - edgeOne - edgeTwo);

            return new Triangle(edgeOne, edgeTwo, edgeThree);
        }
    }
}
