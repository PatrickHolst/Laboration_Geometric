﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public class Triangle : Shape2D
    {
        Vector2 P1, P2, P3;
        public override Vector3 Center => new Vector3((P1.X + P2.X + P3.X) / 3.0f, (P1.Y + P2.Y + P3.Y) / 3.0f, 0);
        public override float Circumference => (P1 - P2).Length() + (P2 - P3).Length() + (P3 - P1).Length();
        public override float Area { get; }

        public Triangle(Vector2 p1, Vector2 p2, Vector2 p3)
        {
            P1 = p1;
            P2 = p2;
            P3 = p3;

            Area = (P1.X * (P2.Y - P3.Y) + P2.X * (P3.Y - P1.Y) + P3.X * (P1.Y - P2.Y)) / 2f;
        }

        public override string ToString()
        {
            return $"Triangle @({Center.X:0.0}, {Center.Y:0.0}): p1 = {P1.X:0.0}, {P1.Y:0.0} p2 = {P2.X:0.0}, {P2.Y:0.0} p3 = {P3.X:0.0}, {P3.Y:0.0})";
        }

    }
}
