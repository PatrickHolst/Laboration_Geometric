﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;

namespace Shapes
{
    public abstract class Shape2D : Shape
    {
        public abstract float Circumference { get; }
    }
}