﻿using System;
using System.Collections.Generic;
using System.Numerics;
using Shapes;

namespace Laboration_2
{
    class Program
    {
        //Framställt med hjälp utav Markus Johansson & Joakim Forslund
        static void Main(string[] args)
        {
            Console.WriteLine("Create or generate center");
            Console.WriteLine("Press >C< to CREATE, >G< to GENERATE");

            var shapes = new List<Shape>();
            var userChoice = "";

            while (userChoice != "C" || userChoice != "c" || userChoice != "G" || userChoice != "g")
            {
                userChoice = Console.ReadLine();
                if (userChoice == "C" || userChoice == "c")
                {
                    Console.Write("Input center for X:\n");
                    var X = float.Parse(Console.ReadLine());
                    Console.Write("Input center for Y:\n");
                    var Y = float.Parse(Console.ReadLine());
                    Console.Write("Input center for Z:\n");
                    var Z = float.Parse(Console.ReadLine());

                    Vector3 user = new Vector3(X, Y, Z);

                    for (int i = 0; i < 20; i++)
                    {
                        shapes.Add(Shape.GenerateShape(user));
                    }
                    break;
                }
                else if (userChoice == "G" || userChoice == "g")
                {
                    for (int i = 0; i < 20; i++)
                    {
                        shapes.Add(Shape.GenerateShape());
                    }
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Wrong input, try again");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }

            PrintValues(shapes);
        }

        public static void PrintValues(List<Shape> ShapeList)
        {
            float circTriangles = 0;
            float averageShapeArea = 0;
            float biggestVolume = 0;
            string largestShape = "";
            Shape3D shape3D;

            int lineCount = 1;
            foreach (var shape in ShapeList)
            {
                if (shape is Triangle)
                {
                    var triangle = shape as Triangle;
                    circTriangles += triangle.Circumference;
                    Console.WriteLine($"#{lineCount++}: {triangle}");

                }
                else
                {
                    Console.WriteLine($"#{lineCount++}: {shape}");

                }

                averageShapeArea += shape.Area;

                if (shape is Shape3D)
                {
                    shape3D = shape as Shape3D;
                    if (biggestVolume < shape3D.Volume)
                    {
                        biggestVolume = shape3D.Volume;
                        largestShape = shape3D.ToString();
                    }
                }
            }

            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine("\n+---------------------------------+\n");
            Console.Write($"Total circ. for triangles is {circTriangles}, ");
            Console.WriteLine($"and the average area of all shapes is {averageShapeArea / 20}.");
            Console.WriteLine($"{largestShape} is largest with a volume of {biggestVolume}.");
        }

    }
}
